# AFSTI Value Chain Dashboard — Status Briefing
**Date:** 17 February 2026
**Author:** Zweli Gwebityala / Claude working session
**Purpose:** Carry-over context for next conversation. Drop this into a new chat to resume.

---

## The Task

Build interactive HTML dashboards (short format) for each country's priority value chains. Each dashboard follows a 6-tab structure:

1. **Governing thought** — KPIs, thesis, signal boxes
2. **Cost physics** — Decomposition table, benchmark comparison, sensitivity
3. **Demand fit** — Product-market match by sink market (format, cuts, specs)
4. **Ecosystem map** — 6-node value chain with BIND/LOSS/MARKET flags
5. **Brick-level projects** — Constraint → Intervention → Impact, each with kill condition
6. **Players & field tests** — Named operators + site-visit questions

**Design spec:** White background, black body text, AGRA green (#1B5E20) headings. Bullets max 5 words. Signal boxes, pill badges, bar charts, KPI cards. McKinsey exhibit style.

**Two versions per country:**
- **Long:** Full prose, detailed reasoning, all evidence
- **Short:** Same structure, bullet-only, scannable in 2 minutes

---

## Country Status

### 1. ZAMBIA — Soya ✅ Analysis complete | ❌ Dashboard not built

**What exists:**
- Interactive React ecosystem map (full value chain: land → farmers → aggregation → crushing → oil/meal split → sinks)
- Cost decomposition in Excel (farmgate $222/t current → $185/t reformed)
- Co-product economics: soya OIL to Angola = FAIL ($2,669/t vs palm $987/t). Pivot to MEAL as real opportunity.
- 5 brick-level projects identified with kill conditions
- Crusher analysis (Mount Meru, Zamanita — contradiction on utilisation to resolve)
- Political economy: Control of Goods Act, 2026 election, FISP distortion, de-dollarisation
- Field visit questions structured
- George Liacopoulos interview notes in project files

**Key finding:** Zambia soy oil is NOT competitive for export. The opportunity is in soy MEAL for regional feed markets (Malawi poultry, DRC, Tanzania). The cross-corridor linkage to Malawi Poultry Project #1 (feed hub) is the strongest investment case.

**What's needed:** Convert existing analysis into short-format HTML dashboard matching Malawi template.

**Project files to reference:**
- `/mnt/project/Zambia_Soya_Oil_CORRECTED_20260130.xlsx`
- `/mnt/project/vc_soya_zambia.html` (existing React ecosystem map)
- `/mnt/project/20260203_Interview_Notes_Zambia-Zimbabwe_Zdenakie_Commodities_Geaorge_Liacopoulos.docx`

---

### 2. TANZANIA — Maize + Pigeon Pea ✅ Analysis complete | ❌ Dashboard not built

**What exists:**
- Maize cost decomposition: Tanzania FOB $580/t vs SA $306/t — 35%+ cost advantage
- Import parity analysis: TZ to Kenya $249/t vs SA to Kenya $359/t
- Pigeon pea cost model built
- G2G deals: 1.15MMT already signed
- Unique selling point: only non-GMO white maize supplier in region
- Political economy: export ban history is THE constraint (not economics)

**Key finding:** Economics are compelling. Policy risk is the killer. Structure deals via G2G (NFRA to FRA) not private trader flows. Export ban = presidential prerogative exercised frequently.

**What's needed:** Convert into short-format HTML dashboard. Need to add demand-fit tab (who buys what format) and brick-level projects.

**Sink markets:** Kenya (primary), Zambia, Malawi, Zimbabwe (all deficit)

---

### 3. MALAWI — Poultry ✅ COMPLETE

**What exists:**
- `vc_poultry_malawi_long.html` — Full prose version, 6 tabs, all evidence
- `vc_poultry_malawi_short.html` — Exhibit-style, bullets, charts, max 5 words

**Key findings:**
- Production 83kt, consumption 71kt, ~12kt surplus
- Feed = 60-70% of cost (binding constraint #1)
- Zero export-certified processing (binding constraint #2, binary gate)
- Angola (258kt) is OUT of primary targeting — wrong product, wrong distance
- Mozambique (50kt) is PRIMARY — chilled portions, 800km, SADC tariff-free
- Malawi's smaller bird (1.5-2kg) is actually advantage for Moz portions market
- Processing must be DUAL FORMAT: Line A chilled (Moz retail) + Line B IQF frozen (informal/DRC)
- 5 projects: Feed hub ($15-25M) → Hatchery ($5-10M) → Contract farming ($3-8M) → Export processing ($10-17M) → Cold chain ($10-20M)
- Total capex $41-78M, steady-state value $17M/yr
- Cross-corridor linkage: Malawi feed hub sources Zambia soy meal (AFSTI Zambia Project #3)

**Abandon if 2+ true:** Zambia soy >$580/t, Central Poultry won't co-invest, export restrictions, HPAI >6mo, Moz SPS won't recognise MBS

---

### 4. ZIMBABWE — ❌ NOT STARTED

**What exists (fragments only):**
- George Liacopoulos interview notes: `/mnt/project/20260203_Interview_Notes_Zambia-Zimbabwe_Zdenakie_Commodities_Geaorge_Liacopoulos.docx`
- Limpopo livestock xlsx references: feed crisis, 1.5MMT corn import needed, 100% soy meal imported
- Assessment rubric has Zim as part of Limpopo corridor

**Likely VCs to investigate:**
- Soya/maize: Zim is massive DEFICIT market (imports 100% soy meal, 1.5MMT corn)
- Livestock: cattle herd exists but constrained by feed, FMD, processing
- Tobacco: existing export infrastructure but not AFSTI-relevant
- Horticulture: historical strength, collapsed post-2000

**Key PE issues to research:**
- Currency (ZiG stability), land tenure, sanctions/diplomatic complexity
- Import dependency makes Zim a SINK not a SOURCE — different framing needed
- Beitbridge border: 3-5 day truck queues, customs strikes

**What's needed:** Full analysis from scratch — VC identification, cost physics, demand analysis, projects, dashboard (long + short).

---

### 5. NIGERIA — Rice + Palm Oil ✅ Analysis complete | ❌ Dashboard not built

**What exists:**
- Rice: Full 4-scenario Excel model (8 tabs + dashboard). 7-page PDF analysis.
  - Verdict: <20% probability of becoming net exporter. Reframe to import substitution ($800M/yr saved).
  - "Latent demand trap": moderate yield improvements get eaten by population growth
  - Political economy: export bans = electoral insurance, Benin arbitrage, policy volatility
- Rice one-pager PPTX sent to manager (Mali + Nigeria combined)
- Palm oil: Diagnostic storyline for Abidjan-Lagos corridor
  - CIV as source, Nigeria as sink ($4B+ import bill)
  - Policy stability ratings by country
  - Palm oil model recalibrated Jan 2026: Yield 7→10 t/ha, OER 14%→18%, reformed $539/t vs $895 benchmark

**Key finding (Rice):** Nigeria should NOT be framed as rice exporter. The honest case is import substitution. Mali has production but ECOWAS exit + military government = no-go.

**Key finding (Palm Oil):** CIV → Nigeria is the real opportunity on Abidjan-Lagos. Structural advantage ~$229/t (64% of gap). Nigeria's 35% non-ECOWAS tariff creates natural protection.

**What's needed:** Convert rice + palm oil analyses into short-format HTML dashboards. May need to split into two dashboards (rice = Dakar-Lagos, palm oil = Abidjan-Lagos).

**Project files:**
- `/mnt/project/Updated_Nigeria__Mali_Rice_Analysis_2.pdf`
- `/mnt/project/AFSTI_Maize_Competitiveness_Context.pdf`

---

## Priority Order for Next Sessions

| # | Country | Effort | Why this order |
|---|---------|--------|----------------|
| 1 | **Zimbabwe** | Heavy (from scratch) | Only country with zero analysis. Blocks SteerCo completeness. |
| 2 | **Tanzania** | Medium (convert existing) | Analysis done, just needs dashboard format + demand fit + projects |
| 3 | **Nigeria** | Medium (convert existing) | Two VCs to dashboard. May split rice/palm oil. |
| 4 | **Zambia** | Light (convert existing) | React map exists. Reformat to short HTML template. |

---

## Cross-Corridor Linkages (Critical for AGRA positioning)

These linkages are what makes AFSTI more than a collection of country studies:

- **Zambia soy meal → Malawi poultry feed** (Zambia Project #3 → Malawi Project #1)
- **Tanzania maize → Zambia/Malawi deficit** (feeds livestock VCs in both countries)
- **CIV palm oil → Nigeria deficit** (Abidjan-Lagos corridor core logic)
- **Zimbabwe as regional demand sink** (absorbs Zambia soy meal + maize + Botswana beef)

---

## Design & Technical Notes

- All dashboards are single-file HTML (no dependencies)
- Light theme: white bg, black text (#1a1a1a), AGRA green headings (#1B5E20)
- Amber (#8B6914) for warnings, Red (#c0392b) for kills/fails
- 6-tab navigation with JS toggle
- Responsive grid (collapses on mobile)
- Save both long + short versions per country
- File naming: `vc_{commodity}_{country}_long.html` / `vc_{commodity}_{country}_short.html`
